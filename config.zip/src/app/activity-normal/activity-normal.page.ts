import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FetchService } from '../fetch.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import * as HighCharts from 'highcharts';

@Component({
  selector: 'app-activity-normal',
  templateUrl: './activity-normal.page.html',
  styleUrls: ['./activity-normal.page.scss'],
})
export class ActivityNormalPage implements OnInit {
model:any={};
  constructor(
	private http: HttpClient,
	private route: ActivatedRoute,
	private router: Router,
	private fetch: FetchService,
  ) { }

  ngOnInit() {
	this.model.user_id = JSON.parse(localStorage.getItem('user_registerd'));
	console.log(this.model.user_id);
	this.fetch.get_user_city(this.model.user_id).subscribe(res => {
		console.log(res.data['city']);
		this.fetch.get_top_donors(res.data['city']).subscribe(res2 => {
			console.log(res2);
			this.model.top_donors = res2.data;
		});
	});
	this.fetch.show_feedback().subscribe(res => {
		console.log(res);
		this.model.feedback_data = res.data;
	});
	this.plotSimpleBarChart();
  }
  
  plotSimpleBarChart() {
    
	let myChart = HighCharts.chart('highcharts', {
		chart: {
			type: 'spline',
			backgroundColor: '#F7F6F4',
		},
		title: {
			text: ''
		},
		xAxis: {
			categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
		},
		yAxis: {
			gridLineWidth: 0,
			min: 0,
			max: 12,
			tickInterval: 4,
			tickPixelInterval : 1,
			title: {
				text: ''
			}
		},
		plotOptions: {
			series: {
				marker: {
					enabled: false
				}
			}
		},
		series: [{
			name: '',
			type: undefined,
			color: '#419B95',
			data: [2, 5, 11, 7, 9, 6, 11]
        }]
    });
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ActivityNormalPageRoutingModule } from './activity-normal-routing.module';

import { ActivityNormalPage } from './activity-normal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ActivityNormalPageRoutingModule
  ],
  declarations: [ActivityNormalPage]
})
export class ActivityNormalPageModule {}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-volunteer-food-drop',
  templateUrl: './volunteer-food-drop.page.html',
  styleUrls: ['./volunteer-food-drop.page.scss'],
})
export class VolunteerFoodDropPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

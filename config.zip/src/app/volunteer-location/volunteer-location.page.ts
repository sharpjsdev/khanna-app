import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-volunteer-location',
  templateUrl: './volunteer-location.page.html',
  styleUrls: ['./volunteer-location.page.scss'],
})
export class VolunteerLocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-volunteer-list',
  templateUrl: './volunteer-list.page.html',
  styleUrls: ['./volunteer-list.page.scss'],
})
export class VolunteerListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
